package com.tomoni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TomcatServerMoniSysApplication {

    public static void main(String[] args) {
        SpringApplication.run(TomcatServerMoniSysApplication.class, args);
    }

}
